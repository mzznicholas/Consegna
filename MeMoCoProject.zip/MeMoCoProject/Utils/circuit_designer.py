import sys

from PyQt5.QtGui import QKeySequence
from PyQt5.QtWidgets import QApplication, QMainWindow, QWidget, QVBoxLayout, QGridLayout, QLabel, QShortcut, \
    QMessageBox, QInputDialog, QHBoxLayout, QPushButton, QDoubleSpinBox, QRadioButton
from math import sqrt

NUM_ROWS = 40
NUM_COLS = 80
CELL_SIZE = 15

REAL_DIR = "../datasets/real/"
EVALUATION_DIR = "../datasets/evaluation/"

WORKING_DIR = REAL_DIR   # if len(sys.argv) < 2 else (sys.argv[1] if sys.argv[1].endswith("/") else sys.argv[1] + "/")


def set_real_dir():
    global WORKING_DIR
    WORKING_DIR = REAL_DIR


def set_evaluation_dir():
    global WORKING_DIR
    WORKING_DIR = EVALUATION_DIR


class GridWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Circuit Designer")
        self.setGeometry(100, 100, 600, 600)

        # Create a central widget and a layout
        central_widget = QWidget(self)
        self.setCentralWidget(central_widget)
        main_layout = QVBoxLayout(central_widget)

        self.counter_lbl = QLabel("Num of holes: 0")
        main_layout.addWidget(self.counter_lbl)

        # Create a grid layout
        grid_layout = QGridLayout()
        grid_layout.setHorizontalSpacing(1)  # Adjust the horizontal spacing between cells
        grid_layout.setVerticalSpacing(1)  # Adjust the vertical spacing between cells
        main_layout.addLayout(grid_layout)

        menu = QHBoxLayout()

        save_btn = QPushButton("Save (CTRL + S)")
        save_btn.clicked.connect(self.save)

        load_btn = QPushButton("Load (CTRL + L)")
        load_btn.clicked.connect(self.load)

        menu.addWidget(save_btn)
        menu.addWidget(load_btn)

        menu.addWidget(QLabel("Up factor:"))
        self.up_sb = QDoubleSpinBox()
        self.up_sb.setValue(1.0)
        self.up_sb.setRange(0.1, 10.00)
        self.up_sb.setSingleStep(0.5)
        menu.addWidget(self.up_sb)

        menu.addWidget(QLabel("Down factor:"))
        self.down_sb = QDoubleSpinBox()
        self.down_sb.setValue(1.0)
        self.down_sb.setRange(0.1, 10.00)
        self.down_sb.setSingleStep(0.5)
        menu.addWidget(self.down_sb)

        menu.addWidget(QLabel("Left factor:"))
        self.left_sb = QDoubleSpinBox()
        self.left_sb.setValue(1.0)
        self.left_sb.setRange(0.1, 10.00)
        self.left_sb.setSingleStep(0.5)
        menu.addWidget(self.left_sb)

        menu.addWidget(QLabel("Right factor:"))
        self.right_sb = QDoubleSpinBox()
        self.right_sb.setValue(1.0)
        self.right_sb.setRange(0.1, 10.00)
        self.right_sb.setSingleStep(0.5)
        menu.addWidget(self.right_sb)

        self.evaluation_dataset_rb = QRadioButton("Evaluation")
        self.evaluation_dataset_rb.toggled.connect(lambda x: set_evaluation_dir() if x else set_real_dir())

        self.real_dataset_rb = QRadioButton("Real")

        self.evaluation_dataset_rb.setChecked(True)

        menu.addWidget(self.evaluation_dataset_rb)
        menu.addWidget(self.real_dataset_rb)

        main_layout.addLayout(menu)

        # Create the grid cells
        cell_size = CELL_SIZE  # Adjust the size of each cell
        self.cells = [[QLabel() for _ in range(NUM_COLS)] for _ in range(NUM_ROWS)]
        self.blue_cells = []
        self.positions = {}
        for row in range(NUM_ROWS):
            for col in range(NUM_COLS):
                cell_label = self.cells[row][col]
                cell_label.setFixedSize(cell_size, cell_size)
                cell_label.setFrameStyle(QLabel.Box)
                cell_label.setStyleSheet("border: 1px solid black;")
                cell_label.mousePressEvent = self.create_mouse_press_event(cell_label, row, col)
                grid_layout.addWidget(cell_label, row, col)

        # Create a shortcut for CTRL + S
        shortcut = QShortcut(QKeySequence("Ctrl+S"), self)
        shortcut.activated.connect(self.save)

        # Create a shortcut for CTRL + L
        shortcut = QShortcut(QKeySequence("Ctrl+L"), self)
        shortcut.activated.connect(self.load)

        self.last_name = ""

    def update_counter(self):
        self.counter_lbl.setText(f"Num of holes: {len(self.blue_cells)}")

    def create_mouse_press_event(self, cell_label, row, col):
        def mouse_press_event(event):
            if cell_label in self.blue_cells:
                self.blue_cells.remove(cell_label)
                del self.positions[cell_label]
                cell_label.setStyleSheet("border: 1px solid black;")
            else:
                self.blue_cells.append(cell_label)
                self.positions[cell_label] = (row, col)
                cell_label.setStyleSheet("background-color: darkcyan; border: 1px solid black;")

            self.update_counter()
        return mouse_press_event

    def add_blue_cell(self, row, col):
        if 0 <= row < NUM_ROWS and 0 <= col < NUM_COLS:
            cell_label = self.cells[row][col]
            if cell_label not in self.blue_cells:
                self.blue_cells.append(cell_label)
                self.positions[cell_label] = (row, col)
                cell_label.setStyleSheet("background-color: darkcyan; border: 1px solid black;")
        self.update_counter()

    def up_factor(self):
        return float(self.up_sb.text().replace(',', '.'))

    def down_factor(self):
        return float(self.down_sb.text().replace(',', '.'))

    def left_factor(self):
        return float(self.left_sb.text().replace(',', '.'))

    def right_factor(self):
        return float(self.right_sb.text().replace(',', '.'))

    def _distance(self, from_node, to_node):
        # 0 -> y
        # 1 -> x

        x_factor = 1.0
        y_factor = 1.0

        if from_node[1] < to_node[1]:
            # moving right
            x_factor = self.right_factor()
        elif from_node[1] > to_node[1]:
            # moving left
            x_factor = self.left_factor()

        # N.B. we are in the 4th cartesian quadrant
        if from_node[0] > to_node[0]:
            # moving up
            y_factor = self.up_factor()
        elif from_node[0] < to_node[0]:
            # moving down
            y_factor = self.down_factor()

        return round(sqrt(pow((to_node[1] - from_node[1]) / x_factor, 2) +
                          pow((to_node[0] - from_node[0]) / y_factor, 2)), 3)

    def save(self):
        name, submitted = QInputDialog.getText(self, "SAVE", "Saving: Type your instance name", text=self.last_name)

        if not submitted or not name:
            return

        self.last_name = name
        costs = []
        for from_n in self.positions.values():
            costs.append([self._distance(from_n, to_n) for to_n in self.positions.values()])
        with open(WORKING_DIR + name + ".tsp", "w") as tsp_file:
            tsp_file.write(str(len(costs)) + '\n')
            lines = []
            for line in costs:
                lines.append(" ".join(map(str, line)))
            tsp_file.write('\n'.join(lines))
        with open(WORKING_DIR + name + ".design", "w") as design_file, \
                open(WORKING_DIR + name + ".legend", "w") as legend_file:
            design_file.write(f"{self.up_factor()} {self.down_factor()} {self.left_factor()} {self.right_factor()}\n")
            design_lines = '\n'.join([" ".join(map(str, line)) for line in self.positions.values()])
            legend_lines = '\n'.join([f"{line}: {index}" for index, line in enumerate(self.positions.values())])

            design_file.write(design_lines)
            legend_file.write(legend_lines)

        QMessageBox.information(self, "Success",
                                f"Circuit has been saved in {WORKING_DIR} directory:\n\n- {name}.tsp\n- {name}.design\n- {name}.legend")

    def load(self):
        name, submitted = QInputDialog.getText(self, "LOAD", "Loading: Type your instance name", text=self.last_name)

        if not submitted or not name:
            return

        self.last_name = name
        try:
            with open(WORKING_DIR + name + ".design", "r") as design_file:
                factors = list(map(float, design_file.readline().split()))

                self.up_sb.setValue(factors[0])
                self.down_sb.setValue(factors[1])
                self.left_sb.setValue(factors[2])
                self.right_sb.setValue(factors[3])

                for line in design_file:
                    row, col = map(int, line.split())
                    self.add_blue_cell(row, col)
            QMessageBox.information(self, "Success", f"{name} has been loaded correctly")
        except FileNotFoundError:
            QMessageBox.warning(self, "Not found", f"File {name}.design not found")


if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = GridWindow()
    window.show()

    sys.exit(app.exec_())
