import glob
import subprocess
import time
import sys
import tqdm

times = 5

folder = "../datasets/evaluation/"
tsp_path = glob.glob(folder + "*.tsp")
tsp_files = [ path.split('/')[-1] for path in tsp_path ]

def file_key(file):
    name = file.split('_')
    return (int((name[1]).split('.')[0]), name[0])


tsp_files.sort(key=file_key)

#FILE_NAME: [GEN1_AVG, GEN2_AVG....]
error_data = {}

for file in tsp_files:
    n = int((file.split('_')[1]).split('.')[0])

    print(f"Running {times} times: {file}")


    instance_convergences = []

    for i in tqdm.tqdm(range(times)):

        p = subprocess.Popen(["../genetic_algorithm/main", file, folder, str(n * 10), "1000", "0.05", str(int(n / 2))], stderr=subprocess.PIPE, stdout=subprocess.DEVNULL)
        
        #wait process ends
        p.wait()
        
        #ensure to get all lines
        sys.stderr.flush()

        result = [float(val.decode().strip()) for val in p.stderr.readlines()]
        instance_convergences.append(result)
        
    average_convergence = [round(sum(gen) / len(gen), 5) for gen in zip(*instance_convergences)]

    error_data[file] = average_convergence

    time.sleep(1)

n = len(error_data[list(error_data.keys())[0]])

with open("convergence.csv", "w") as file:
    line = ",".join(tsp_files)
    file.write(line + "\n")

    for i in range(n):
        line_data = []
        for key in tsp_files:
            line_data.append(error_data[key][i])
    
        file.write(",".join(map(str, line_data)) + "\n")
