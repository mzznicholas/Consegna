import glob

"""
report format:
SIZE
VAL1 duration1
VAL2 duration2
VAL3 duration3

In cplex reports all values are equal (always optimal value). Size may always be the same
"""


class Report:
    def __init__(self, duration, error):
        self.duration = duration
        self.error = error


def reports_loader(working_dir):
    cplex = {}
    heuristic = {}

    cplex_reports = glob.glob(working_dir + "*.tsp.cplex.rep")
    heuristic_reports = glob.glob(working_dir + "*.tsp.ga.rep")

    dict_groups = [cplex, heuristic]
    file_groups = [cplex_reports, heuristic_reports]

    for d, group in zip(dict_groups, file_groups):
        for file_path in group:
            with open(file_path) as file:
                n = int(file.readline())
                d[n] = []
                for line in file:
                    data = list(map(float, line.split()))
                    d[n].append(Report(data[0], data[2]))

    return cplex, heuristic


def avg(report):
    report_avg = {}

    for k, v in report.items():

        duration_sum = 0.0
        error_sum = 0.0
        n_elem = len(v)

        for sample in v:
            error_sum += sample.error
            duration_sum += sample.duration

        report_avg[k] = Report(duration_sum / n_elem, error_sum / n_elem)

    return report_avg


def print(report_avg):
    print("|N| duration error")
    for k, v in report_avg:
        print(f"{k} {v.duration} {v.error}")
