import sys
import matplotlib.pyplot as plt
import numpy as np

import statistics

import helpers

WORKING_DIR = "../datasets/real/" if len(sys.argv) < 2 else (
    sys.argv[1] if sys.argv[1].endswith("/") else sys.argv[1] + "/")


def main():
    cplex, heuristic = helpers.reports_loader(WORKING_DIR + "reports/")

    cplex_avg = helpers.avg(cplex)
    heuristic_avg = helpers.avg(heuristic)

    labels = [s for s in sorted(cplex_avg.keys())]

    cplex_duration = [cplex_avg[k].duration for k in labels]
    heuristic_duration = [heuristic_avg[k].duration for k in labels]

    print("CPLEX")
    print(cplex_avg)

    print()
    print("GA")
    print("Size;Min;Max;Avg Error;Stdev;CV;Avg Time")
    for s in labels:
        standard_dev = statistics.stdev([i.error for i in heuristic[s]])
        print(f"{s};{min(heuristic[s], key=lambda x: x.error).error};"
              f"{max(heuristic[s], key=lambda x: x.error).error};"
              f"{round(heuristic_avg[s].error, 5)};{round(standard_dev, 5)};"
              f"{round(standard_dev / heuristic_avg[s].error, 5)};"
              f"{heuristic_avg[s].duration}")



    fig, ax = plt.subplots()

    h = 0.35
    y = np.arange(len(labels))

    ax.barh(y - h / 2, cplex_duration, label="CPLEX", height=h)
    ax.barh(y + h / 2, heuristic_duration, label="GA Heuristic", height=h)
    ax.invert_yaxis()

    for bars in ax.containers:
        ax.bar_label(bars)
    
    ax.set_yticks(y)
    ax.set_yticklabels(labels)

    ax.legend()

    plt.title("Average duration comparison")
    plt.xlabel("Duration (ms)")
    plt.ylabel("N")

    # error
    fig, ax = plt.subplots()
    heuristic_error = [heuristic_avg[k].error for k in labels]


    # error = abs(heuristic - cplex) / cplex
    # error_val = [(abs(h - c) / c) * 100 for c, h in zip(cplex_val, heuristic_val)]

    ax.set_xticks(labels)

    ax.plot(labels, heuristic_error, label="GA", marker='o')
    ax.legend()
    ax.axhline(y=0.10, color='red', linestyle='--')
    ax.axhline(y=0.05, color='orange', linestyle='--')

    plt.title("GA Heuristic average relative error")
    plt.xlabel("N")
    plt.ylabel("Error (%)")
    plt.grid(True)

    # cplex-only
    fig, ax = plt.subplots()

    ax.set_xticks(labels)

    ax.plot(labels, cplex_duration, label="CPLEX", marker='o')
    ax.legend()

    plt.title("CPLEX execution time")
    plt.xlabel("N")
    plt.ylabel("Execution time (ms)")
    plt.grid(True)
    plt.show()



if __name__ == '__main__':
    main()
