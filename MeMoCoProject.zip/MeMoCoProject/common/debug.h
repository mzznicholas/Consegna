#ifndef D_MSG

#ifdef DEBUG
#define D(x) do { x; } while(0)
#define D_MSG(x) do { std::cout << x << std::endl; } while(0)
#define D_E(x) do { std::cerr << x << std::endl; } while(0)
#else
#define D(x)
#define D_MSG(x)
#define D_E(x)
#endif

#endif
