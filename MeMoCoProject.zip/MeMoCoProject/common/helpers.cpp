#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include <string>

#include "helpers.h"

bool Helpers::ends_with(const char *str, char c) {
    std::string s(str);
    if (!s.empty() && s.back() == c)
        return true;
    return false;
}

void Helpers::add_slash_if_missing(char *target, const char *source) {
    strcpy(target, source);

    if (!Helpers::ends_with(target, '/')) {
        const char *s = "/";
        strcat(target, s);
    }
}

void Helpers::create_report_path(char *report_path, const char *wd, const char *file_name, const char *type) {
    strcpy(report_path, wd);
    strcat(report_path, "reports/");
    strcat(report_path, file_name);
    strcat(report_path, ".");
    strcat(report_path, type);
    strcat(report_path, ".rep");
}

void Helpers::write_report(const char *file_path, int &N, const double &value, const long long &duration, const double error) {
    std::string path = std::string(file_path);
    std::fstream file(path, std::ios_base::app);

    if (file.is_open()) {

        if (file.tellg() == std::streampos(0)) {
            file << N;
        }

        file << std::endl << duration << " " << value;
        if(error >= 0) {
            file << " " << error;
        }

        file.close();

    } else {
        throw std::runtime_error("Failed to open report file");
    }

}

double Helpers::read_TSP(const char *file_path, int &N, std::vector<std::vector<double> > &cost, double &inf) {
    std::string path = std::string(file_path);
    std::ifstream file(path);
    double optimal = -1;

    if (file.is_open()) {
        std::string line;
        std::getline(file, line);

        /** start from fist line **/
        std::stringstream ss(line);
        std::string cell_value;

        /** read N **/
        ss >> cell_value;
        N = std::stoi(cell_value);

        /** read optimal value, if any **/
        if (ss >> cell_value) {
            optimal = std::stod(cell_value);
        }

        inf = 0;
        /** read cost values **/
        while (std::getline(file, line)) {
            std::vector<double> row;
            std::stringstream rowSteam(line);

            while (rowSteam >> cell_value) {
                double c = std::stod(cell_value);
                inf += c;
                row.push_back(c);
            }
            cost.push_back(row);
        }
        file.close();
    } else {
        throw std::runtime_error("Failed to open TSP file");
    }
    return optimal;
}
