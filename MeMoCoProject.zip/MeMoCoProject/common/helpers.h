#ifndef COMMON_HELPERS_H
#define COMMON_HELPERS_H


#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include <string>


class Helpers {
    public:
    static bool ends_with(const char *str, char c);
    static void add_slash_if_missing(char *, const char *);
    static void create_report_path(char *, const char *, const char *, const char *);
    static void write_report(const char *, int &, const double &value, const long long &, const double = 0);

    static double read_TSP(const char *, int &, std::vector<std::vector<double> > &, double &);
};


#endif //COMMON_HELPERS_H