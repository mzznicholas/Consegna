#!/bin/bash
folder="./datasets/correctness"
failed_list=()

for path in $folder/*.tsp; do    
    file=$(basename "$path")
    ./cplex_model/main $file "$folder" > /dev/null
    if [ $? -ne 0 ]; then
        echo "- - - - $file: FAILED - - - -"
    else
        echo "$file: OK"
    fi
done