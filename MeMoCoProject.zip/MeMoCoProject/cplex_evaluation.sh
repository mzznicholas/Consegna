#!/bin/bash
folder="./datasets/evaluation"

iterations=${1:-10}

if [ $# -eq 0 ]; then
    echo -e "Number of iterations not provided, using 10 by default\n"
fi

for path in $folder/*.tsp; do
    file=$(basename "$path")
    for ((i=0; i < iterations; i++)); do
        echo "$file $((i+1))/$iterations"
        ./cplex_model/main "$file" "$folder" > /dev/null
    done
done