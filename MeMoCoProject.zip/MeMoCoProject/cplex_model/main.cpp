#include <iostream>
#include <cmath>
#include <vector>
#include <string>
#include <cstring>

#include "cpxmacro.h"

#include "setup.h"

#include "../common/helpers.h"
#include "../common/debug.h"


int status;
char errmsg[BUF_SIZE];


void setup(Env env, Prob lp, int &N, std::vector<std::vector<double> > &cost) {
    Setup::create_variables(env, lp, N, cost);

    Setup::constraint_10(env, lp, N);
    Setup::constraint_11(env, lp, N);
    Setup::constraint_12(env, lp, N);
    Setup::constraint_13(env, lp, N);

    /* Create a MINIMIZATION problem */
    CHECKED_CPX_CALL(CPXchgobjsen, env, lp, CPX_MIN); //actually, already min prob
}

int main(int argc, char *argv[]) {

    if (argc < 2) {
        std::cout << "Usage: ./main [TSP file] [Working directory](optional)" << std::endl;
        return -1;
    }

    const char *file_name = argv[1];
    const char *unsafe_wd = argc >= 3 ? argv[2] : "../datasets/";

    char wd[256];
    Helpers::add_slash_if_missing(wd, unsafe_wd);

    char file_path[256];
    strcpy(file_path, wd);
    strcat(file_path, file_name);

    std::cout << "Finding optimal tour for " << file_path << "...." << std::endl << std::endl;

    DECL_ENV(env);
    DECL_PROB(env, lp);


    std::vector<std::vector<double> > cost;
    int N;
    double infinite;

    double expected_optimal = Helpers::read_TSP(file_path, N, cost, infinite);

    D_MSG("Configuring....");

    auto start = std::chrono::high_resolution_clock::now();
    setup(env, lp, N, cost);

    D(CHECKED_CPX_CALL(CPXwriteprob, env, lp, "tsp.lp", NULL));

    D_MSG("Solving....");

    /* SOLVE */
    CHECKED_CPX_CALL(CPXmipopt, env, lp);

    D_MSG("Model has been solved without errors");

    auto end = std::chrono::high_resolution_clock::now();

    auto duration = std::chrono::duration_cast<std::chrono::microseconds>(end - start).count() / 1000;


    D(CHECKED_CPX_CALL(CPXsolwrite, env, lp, "tsp.sol"));

    double obj_val;
    CHECKED_CPX_CALL(CPXgetobjval, env, lp, &obj_val);

    std::cout << "Found optimal: " << obj_val << " in " << duration << " milliseconds" << std::endl;

    char report_path[256];
    Helpers::create_report_path(report_path, wd, file_name, "cplex");

    Helpers::write_report(report_path, N, obj_val, duration);



    if (expected_optimal > 0 && abs(obj_val - expected_optimal) > 1e-10) {
        std::stringstream ss;
        ss << "Declared objective value does NOT match model objective value. Got " << obj_val << " expected " << expected_optimal;

        throw std::logic_error(ss.str());
    }

    int i = 0;
    std::cout << i << " ";

    for(int o = 0; o < N; o++) {
        int j = 0;
        double v = 0;

        while (v < 0.5) {

            int idx = Setup::y(i, j, N);
            CPXgetx(env, lp, &v, idx, idx);

            j++;
        }
        j--;
        std::cout << j << " ";
        i = j;
    }
    std::cout << std::endl;
    D_MSG("End");
    CPXfreeprob(env, &lp);
    CPXcloseCPLEX(&env);

}