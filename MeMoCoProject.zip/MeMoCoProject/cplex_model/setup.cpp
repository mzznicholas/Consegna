//
// Created by Nico on 05/07/23.
//

#include "setup.h"
#include "cpxmacro.h"
#include "../common/debug.h"

const int NAME_SIZE = 512;
char name[NAME_SIZE];


void Setup::create_variables(Env env, Prob lp, const int &N, std::vector<std::vector<double> > &cost) {

    D_MSG("\tCreating decision variables x_i_j....");
    /* Creates decision variables for x_i_j */
    for (int i = 0; i < N; i++) {
        for (int j = 1; j < N; j++) {
            char xtype = 'C';
            double lb = 0.0;
            double ub = CPX_INFBOUND;
            double coeff = 0.0;

            /*if (j == 0) {
                ub = 0.0;
            } */
            snprintf(name, NAME_SIZE, "x_%d_%d", i, j);
            char *xname = (char *) (&name[0]);

            CHECKED_CPX_CALL(CPXnewcols, env, lp, 1, &coeff, &lb, &ub, &xtype, &xname);
        }
    }
    D_MSG("\tCreating decision variables y_i_j....");

    /* Creates decision variables for y_i_j */
    for (int i = 0; i < N; i++) {
        for (int j = 0; j < N; j++) {
            char xtype = 'B';
            double lb = 0.0;
            double ub = 1.0;
            snprintf(name, NAME_SIZE, "y_%d_%d", i, j);
            char *xname = (char *) (&name[0]);

            CHECKED_CPX_CALL(CPXnewcols, env, lp, 1, &cost[i][j], &lb, &ub, &xtype, &xname);
        }
    }

}

void Setup::constraint_10(Env env, Prob lp, const int &N) {
    D_MSG("\tCreating constraints (10)....");

    /* Creates constraints (10) */
    for (int k = 1; k < N; k++) {
        std::vector<int> idx(N + (N - 2));
        std::vector<double> coeff(N + (N - 1));
        double rhs = 1.0;
        char sense = 'E';
        int matbeg = 0;

        int pos = 0;
        for (int i = 0; i < N; i++) {
            if (i == k) continue;

            idx[pos] = x(i, k, N);
            coeff[pos] = 1.0;
            pos++;
        }

        for (int j = 1; j < N; j++) {
            if (j == k) continue;

            idx[pos] = x(k, j, N);

            coeff[pos] = -1.0;
            pos++;
        }

        CHECKED_CPX_CALL(CPXaddrows, env, lp, 0, 1, idx.size(), &rhs, &sense, &matbeg, &idx[0], &coeff[0], 0, 0);
    }

}

void Setup::constraint_11(Env env, Prob lp, const int &N) {
    D_MSG("\tCreating constraints (11)....");
    /* Creates constraints (11) */
    for (int i = 0; i < N; i++) {
        std::vector<int> idx(N);
        std::vector<double> coeff(N, 1.0);
        double rhs = 1.0;
        char sense = 'E';
        int matbeg = 0;

        for (int j = 0; j < N; j++) {
            idx[j] = y(i, j, N);
        }
        CHECKED_CPX_CALL(CPXaddrows, env, lp, 0, 1, idx.size(), &rhs, &sense, &matbeg, &idx[0], &coeff[0], 0, 0);
    }

}

void Setup::constraint_12(Env env, Prob lp, const int &N) {
    D_MSG("\tCreating constraints (12)....");

    /* Creates constraints (12) */
    for (int j = 0; j < N; j++) {
        std::vector<int> idx(N);
        std::vector<double> coeff(N, 1.0);
        double rhs = 1.0;
        char sense = 'E';
        int matbeg = 0;

        for (int i = 0; i < N; i++) {
            idx[i] = y(i, j, N);
        }
        CHECKED_CPX_CALL(CPXaddrows, env, lp, 0, 1, idx.size(), &rhs, &sense, &matbeg, &idx[0], &coeff[0], 0, 0);
    }



}

void Setup::constraint_13(Env env, Prob lp, const int &N) {
    D_MSG("\tCreating constraints (13)....");
    /* Creates constraints (13) */
    for (int i = 0; i < N; i++) {
        for (int j = 1; j < N; j++) {
            std::vector<int> idx(2);
            std::vector<double> coeff(2);

            idx[0] = x(i, j, N);
            idx[1] = y(i, j, N);

            coeff[0] = 1;
            coeff[1] = -(N - 1);
            char sense = 'L';
            double rhs = 0.0;
            int matbeg = 0;
            CHECKED_CPX_CALL(CPXaddrows, env, lp, 0, 1, idx.size(), &rhs, &sense, &matbeg, &idx[0], &coeff[0], 0, 0);
        }
    }
}

int Setup::x(const int &i, const int &j, const int &N) {
    return i * (N - 1) + (j - 1);
}

int Setup::y(const int &i, const int &j, const int &N) {
    return (N * N - N) + i * N + j;
}
