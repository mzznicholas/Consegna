//
// Created by Nico on 05/07/23.
//

#ifndef CPLEX_EXACT_SETUP_H
#define CPLEX_EXACT_SETUP_H


#include "cpxmacro.h"

class Setup {
public:
    static void create_variables(Env env, Prob, const int &N, std::vector<std::vector<double> > &);
    static void constraint_10(Env env, Prob lp, const int &);
    static void constraint_11(Env env, Prob lp, const int &);
    static void constraint_12(Env env, Prob lp, const int &);
    static void constraint_13(Env env, Prob lp, const int &);

    static int x(const int &i, const int &j, const int &N);
    static int y(const int &i, const int &j, const int &N);
};


#endif //CPLEX_EXACT_SETUP_H
