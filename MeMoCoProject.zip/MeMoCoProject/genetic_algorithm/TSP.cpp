#include "TSP.h"
#include "../common/helpers.h"

void TSP::read_from_file(const char *file_path) {
    optimal = Helpers::read_TSP(file_path, N, cost, infinite);
}