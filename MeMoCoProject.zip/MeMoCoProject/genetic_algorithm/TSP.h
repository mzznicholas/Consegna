#ifndef HEURISTIC_TSP_H
#define HEURISTIC_TSP_H

#include <vector>

class TSP {
public:
    int N;
    double optimal;
    double infinite;
    std::vector<std::vector<double>> cost;

    TSP() : N(0), optimal(0), infinite(1e10) {}

    void read_from_file(const char*);
};

#endif //HEURISTIC_TSP_H
