#include <iostream>
#include "TSPSolution.h"

void TSPSolution::print() const {
    for (int i : this->sequence) {
        std::cout << i << " -> ";
    }
    std::cout << this->sequence.front() << std::endl;
}
