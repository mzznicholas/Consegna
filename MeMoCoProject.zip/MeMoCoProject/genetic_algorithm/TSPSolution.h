#ifndef HEURISTIC_TSPSOLUTION_H
#define HEURISTIC_TSPSOLUTION_H

#include <vector>
#include <numeric>
#include "TSP.h"

class TSPSolution {
public:
    int N;
    std::vector<int> sequence;
    double value;

    TSPSolution(): N(0), sequence(), value(0) {}


    explicit TSPSolution(const TSP &tsp) : N(tsp.N), sequence(tsp.N), value(0) {
        std::iota(sequence.begin(), sequence.end(), 0);
    }


    TSPSolution(const TSPSolution &s): N(s.sequence.size()), sequence(s.sequence), value(0) {}

    TSPSolution &operator=(const TSPSolution &right) {
        N = right.N;
        sequence = right.sequence;
        value = 0;
        return *this;
    };

    void print() const;
    virtual ~TSPSolution() = default;

    bool operator<(const TSPSolution &right) {
        return value < right.value;
    }
};


#endif //HEURISTIC_TSPSOLUTION_H
