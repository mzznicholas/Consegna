#include <iostream>
#include <vector>
#include <algorithm>
#include <set>
#include <random>
#include <queue>

#include "TSPSolver.h"

#include "../common/helpers.h"
#include "../common/debug.h"

void TSPSolver::solve(TSPSolution &best_individual) {

    double best_val = tsp.infinite;

    _init_population();

    //std::uniform_int_distribution<int> coin(0, 1);

    for (int gen = 0; gen < N_GENERATIONS; gen++) {

        //std::discrete_distribution<std::size_t> fitness_distr;
        //_compute_prob_distr(fitness_distr);

        SolutionVector new_generation;

        //auto compare_improve = best_val;

        // ELITISM
        _elitism_inheritance(new_generation);

        while (new_generation.size() < POPULATION_SIZE) {

            TSPSolution parent1, parent2;
            _5_tournament_selection(parent1);
            _5_tournament_selection(parent2);

            TSPSolution child;

            /*if (coin(_rgn) == 0) {
                _PMX(parent1, parent2, child);
            } else {
                _OX(parent1, parent2, child);
            }*/

            _OX(parent1, parent2, child);

            _mutation(child);

            new_generation.push_back(std::make_shared<TSPSolution>(child));

            if (evaluate_fitness(child) < best_val) {
                best_individual = child;
                best_val = evaluate_fitness(child);
            }
        }

        D_E(calculate_error(best_individual));
        _population = new_generation;

    }
    
    D(fflush(stderr));
    D_MSG(evaluate_fitness(best_individual));
}

// DONE :)
void TSPSolver::_randomize(TSPSolution &individual) {
    std::shuffle(individual.sequence.begin(), individual.sequence.end(), _rgn);
}

// DONE :)
void TSPSolver::_init_population() {
    _population.reserve(POPULATION_SIZE);

    for (std::size_t i = 0; i < POPULATION_SIZE; i++) {
        TSPSolution sol(tsp);
        _randomize(sol);
        _population.push_back(std::make_shared<TSPSolution>(sol));
    }
}

// DONE :)
double TSPSolver::evaluate_fitness(TSPSolution &individual) const {

    if (individual.value > 0) return individual.value;

    double total = 0.0;
    for (int i = 0; i < individual.N - 1; i++) {
        auto from = individual.sequence[i];
        auto to = individual.sequence[i + 1];
        total += tsp.cost[from][to];
    }

    // return to the initial point
    total += tsp.cost[individual.sequence.back()][individual.sequence.front()];

    return total;
}

void TSPSolver::_elitism_inheritance(SolutionVector &new_generation) {
    // otherwise not waste time on sorting
    if (ELITE_SIZE > 0) {
        // https://stackoverflow.com/questions/16894700/c-custom-compare-function-for-stdsort
        //https://learncplusplus.org/how-to-use-stdsort-with-a-lambda-expression-in-c/
        //cannot be const because cached value
        std::sort(_population.begin(), _population.end(),
                  [this](std::shared_ptr <TSPSolution> &lhs, std::shared_ptr <TSPSolution> &rhs) {
                      return this->evaluate_fitness(*lhs) < this->evaluate_fitness(*rhs);
                  });

        for (int j = 0; j < ELITE_SIZE; j++) {
            new_generation.push_back(_population[j]);
        }
    }
}

// DONE :)
void TSPSolver::_5_tournament_selection(TSPSolution &parent) {

    TSPSolution *champion = nullptr;
    double champion_val = tsp.infinite;

    std::uniform_int_distribution <std::size_t> dist(0, _population.size() - 1);

    std::vector < TSPSolution * > tournament;

    const int k_size = 5;

    tournament.reserve(k_size);

    while (tournament.size() < k_size) {
        std::size_t r = dist(_rgn);

        auto candidate = _population[r].get();
        auto candidate_val = evaluate_fitness(*candidate);

        // NO duplicates in tournament!
        if (std::find(tournament.begin(), tournament.end(), candidate) == tournament.end()) {
            tournament.push_back(candidate);

            if (candidate_val < champion_val) {
                champion_val = candidate_val;
                champion = candidate;
            }
        }
    }

    if (champion != nullptr) {
        parent = *champion;
    } else {
        // never actually reach this point in normal behavior
        throw std::runtime_error("Fatal error, impossible state");
    }

}

void TSPSolver::_fitness_proportional_selection(TSPSolution &parent,
                                                std::discrete_distribution <std::size_t> &propDistribution) {
    parent = *_population[propDistribution(_rgn)];
}

// DONE :)
//assuming child = parent1
void TSPSolver::_PMX(TSPSolution &parent1, TSPSolution &parent2, TSPSolution &child) {

    child = parent1;

    std::uniform_int_distribution <std::size_t> dist(0, parent1.N - 1);
    int a = dist(_rgn);
    int b = dist(_rgn);
    auto from = std::min(a, b);
    auto to = std::max(a, b);

    std::unordered_map<int, int> node_map;

    for (auto i = from; i <= to; i++) {
        node_map[parent2.sequence[i]] = child.sequence[i];

        child.sequence[i] = parent2.sequence[i];
    }

    for (int i = 0; i < parent1.N; i++) {
        if (from <= i && i <= to) continue; // do not override crossover

        if (node_map.find(child.sequence[i]) != node_map.end()) {
            // need to normalize the solution
            child.sequence[i] = _solve_values_chain(node_map, child.sequence[i]);
        }
    }
}

// DONE :)
//assuming child = parent1
void TSPSolver::_OX(TSPSolution &parent1, TSPSolution &parent2, TSPSolution &child) {

    child = parent1;

    std::uniform_int_distribution <std::size_t> dist(0, parent1.N - 1);

    auto a = dist(_rgn);
    auto b = dist(_rgn);

    //retry
    if (a == b) {
        _OX(parent1, parent2, child);
        return;
    }

    auto from = std::min(a, b);
    auto to = std::max(a, b);

    std::set<int> node_set;

    for (auto i = from; i <= to; i++) {
        node_set.insert(parent1.sequence[i]);
    }

    std::size_t free_index = 0;
    for (int i = 0; i < parent1.N; i++) {

        if (free_index == from) free_index = to + 1; //skip cut point

        if (node_set.find(parent2.sequence[i]) == node_set.end()) {
            child.sequence[free_index] = parent2.sequence[i];
            free_index++;
        }
    }
}

// DONE :)
void TSPSolver::_mutation(TSPSolution &individual) {
    std::uniform_real_distribution<double> mutation_dist(0.0, 1.0);
    std::uniform_int_distribution<int> index_dist(0, individual.N - 1);


    auto r = mutation_dist(_rgn);
    if (r < MUTATION_RATE) {
        auto a = index_dist(_rgn);
        auto b = index_dist(_rgn);

        auto from = individual.sequence.begin() + std::min(a, b);
        auto to = individual.sequence.begin() + std::max(a, b);
        std::reverse(from, to + 1);
    }


}

void TSPSolver::_compute_prob_distr(std::discrete_distribution <std::size_t> &distribution) {
    std::vector<double> probabilities;
    probabilities.reserve(POPULATION_SIZE);
    for (auto &individual: _population) {

        //higher prob to lower values
        probabilities.push_back(1.0 / evaluate_fitness(*individual));
    }
    distribution = std::discrete_distribution<std::size_t>(probabilities.begin(), probabilities.end());
}

int TSPSolver::_solve_values_chain(std::unordered_map<int, int> &map, int k) {
    int v = map[k];
    while (map.find(v) != map.end()) {
        k = v;
        v = map[k];
    }
    return v;
}

double TSPSolver::calculate_error(TSPSolution &sol) const {
    if (tsp.optimal > 0) {
        return abs(tsp.optimal - evaluate_fitness(sol)) / tsp.optimal;
    } else {
        return -1;
    }
}
