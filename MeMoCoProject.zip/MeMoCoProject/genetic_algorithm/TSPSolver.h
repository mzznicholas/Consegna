#ifndef HEURISTIC_TSPSOLVER_H
#define HEURISTIC_TSPSOLVER_H

#include <random>

#include "TSP.h"
#include "TSPSolution.h"

typedef std::vector<std::shared_ptr<TSPSolution>> SolutionVector;

class TSPSolver {
public:
    const TSP &tsp;

    explicit TSPSolver(const TSP &tsp, const int population_size, const int n_generations, const float mutation_rate,
                       const int elite_size = 0) :
            tsp(tsp), POPULATION_SIZE(population_size), N_GENERATIONS(n_generations), MUTATION_RATE(mutation_rate),
            ELITE_SIZE(elite_size), _rgn(std::random_device{}()) {}

    void solve(TSPSolution &);

public:
    const std::size_t POPULATION_SIZE;
    const int N_GENERATIONS;
    const float MUTATION_RATE;
    const int ELITE_SIZE;

    double evaluate_fitness(TSPSolution &) const;
    double calculate_error(TSPSolution &) const;


private:
    void _init_population();

    void _randomize(TSPSolution &);

    void _elitism_inheritance(SolutionVector &);

    void _5_tournament_selection(TSPSolution &);

    void _fitness_proportional_selection(TSPSolution &, std::discrete_distribution<std::size_t> &);

    void _PMX(TSPSolution &, TSPSolution &, TSPSolution &);

    void _OX(TSPSolution &, TSPSolution &, TSPSolution &);

    void _mutation(TSPSolution &);

    static int _solve_values_chain(std::unordered_map<int, int> &, int);

    void _compute_prob_distr(std::discrete_distribution<std::size_t> &);


    SolutionVector _population;
    std::mt19937 _rgn;
};


#endif //HEURISTIC_TSPSOLVER_H
