#include <iostream>
#include "TSP.h"
#include "TSPSolver.h"

#include "../common/helpers.h"

#include "../common/debug.h"


int main(int argc, char *argv[]) {

    D_MSG("---- DEBUG MODE: ON ----");

    if (argc < 7) {
        std::cout << "Usage: ./main [TSP FILE] [WORKING DIRECTORY] [POPULATION SIZE]"
                     "[NUM OF GENERATIONS] [MUTATION RATE (decimal)] [ELITISM SIZE]" << std::endl;
        return -1;
    }

    const char *file_name = argv[1];
    const char *unsafe_wd = argv[2];

    const int POPULATION_SIZE = std::stoi(argv[3]);
    const int N_GENERATIONS = std::stoi(argv[4]);
    const float MUTATION_RATE = std::stof(argv[5]);
    const int ELITISM_SIZE = std::stoi(argv[6]);

    D(std::cout << "POPULATION SIZE: " << POPULATION_SIZE << " N GENERATIOS: " << N_GENERATIONS << 
    " MUTATION RATE: " << MUTATION_RATE << " ELITISM SIZE: " << ELITISM_SIZE << std::endl);


    char wd[256];
    Helpers::add_slash_if_missing(wd, unsafe_wd);
    char file_path[256];
    strcpy(file_path, wd);
    strcat(file_path, file_name);


    std::cout << "Starting Genetic Algorithm (Heuristic)...." << std::endl;

    TSP tsp;
    tsp.read_from_file(file_path);
    auto start = std::chrono::high_resolution_clock::now();

    TSPSolver solver(tsp, POPULATION_SIZE, N_GENERATIONS, MUTATION_RATE, ELITISM_SIZE);

    TSPSolution sol(tsp);
    solver.solve(sol);


    auto end = std::chrono::high_resolution_clock::now();

    auto duration = std::chrono::duration_cast<std::chrono::microseconds>(end - start).count() / 1000;

    std::cout << "Genetic Algorithm (Heuristic) terminated. Best solution: " << solver.evaluate_fitness(sol) << " in "
              << duration
              << " milliseconds";

    double error = solver.calculate_error(sol);
    if(error >= 0) {
        std::cout << " with error " << error * 100 << "% ";
    }

    std::cout << std::endl;


    for (int i: sol.sequence) {
        std::cout << i << " ";
    }
    std::cout << std::endl;

    char report_path[256];
    Helpers::create_report_path(report_path, wd, file_name, "ga");
    Helpers::write_report(report_path, tsp.N, solver.evaluate_fitness(sol), duration, error);


    return 0;
}
