#!/bin/bash
folder="./datasets/evaluation/"
iterations=${1:-10}

for path in $folder/*20.tsp; do
    file=$(basename "$path")
    for ((i=0; i < iterations; i++)); do
        echo "$file $((i+1))/$iterations"
        ./genetic_algorithm/main "$file" "$folder" "100" "100" "0.05" "15" > /dev/null
    done
done

for path in $folder/*30.tsp; do
    file=$(basename "$path")
    for ((i=0; i < iterations; i++)); do
        echo "$file $((i+1))/$iterations"
        ./genetic_algorithm/main "$file" "$folder" "150" "225" "0.05" "15" > /dev/null
    done
done

for path in $folder/*40.tsp; do
    file=$(basename "$path")
    for ((i=0; i < iterations; i++)); do
        echo "$file $((i+1))/$iterations"
        ./genetic_algorithm/main "$file" "$folder" "200" "322" "0.05" "25" > /dev/null
    done
done

for path in $folder/*50.tsp; do
    file=$(basename "$path")
    for ((i=0; i < iterations; i++)); do
        echo "$file $((i+1))/$iterations"
        ./genetic_algorithm/main "$file" "$folder" "250" "391" "0.10" "30" > /dev/null
    done
done

for path in $folder/*60.tsp; do
    file=$(basename "$path")
    for ((i=0; i < iterations; i++)); do
        echo "$file $((i+1))/$iterations"
        ./genetic_algorithm/main "$file" "$folder" "600" "433" "0.05" "50" > /dev/null
    done
done

for path in $folder/*70.tsp; do
    file=$(basename "$path")
    for ((i=0; i < iterations; i++)); do
        echo "$file $((i+1))/$iterations"
        ./genetic_algorithm/main "$file" "$folder" "700" "447" "0.05" "60" > /dev/null
    done
done